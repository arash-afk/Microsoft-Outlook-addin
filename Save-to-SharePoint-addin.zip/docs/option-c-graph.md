# Option C — the add-in signs each lawyer in and works as them (recommended)

Files: `taskpane.html`, `lib/` and `manifest.xml` in the repo root. Do the shared **SharePoint setup** in `README.md` first.

This version doesn't use Power Automate. It signs the lawyer in with their Microsoft 365 account, and reads the email and lists, creates and saves in SharePoint **as that lawyer**, through Microsoft Graph.

What this changes:

| | Option B (Power Automate) | Option C |
|---|---|---|
| Who decides what a lawyer can see and do | The flows, by checking permissions for an email address the add-in sent | **SharePoint itself.** The add-in can only do what the lawyer could do in SharePoint |
| Public flow URLs in `taskpane.html` | Yes, anyone could call them | **None.** The page holds only identifiers, no secrets |
| Emails from other lawyers' mailboxes | Only if the flow owner could open their mailbox | **Works for every lawyer**, from their own mailbox |
| "Created by" on saved files | The flow owner's account | **The lawyer who filed it** |
| Flow account needs site owner rights | Yes | No |
| Power Automate usage limits | Every check counted | Not used |

Unchanged: the site list, favourites (they carry over), file naming, attachments saved separately, the duplicate check, and the Subject / From / To / Cc / InternetMessageId columns.

Work through parts A → D in order.

---

## Part A — Register the add-in in Microsoft Entra (admin, ~10 min)

You need an account that can create app registrations and grant admin consent (Global Administrator, or Application Administrator plus Privileged Role Administrator).

### A1. Open App registrations
Go to <https://entra.microsoft.com> → **Entra ID** (or **Identity**) → **App registrations** → **+ New registration**.

### A2. Register
- **Name:** `Save to SharePoint add-in`
- **Supported account types:** *Accounts in this organizational directory only (Single tenant)*
- **Redirect URI:** platform **Single-page application (SPA)**, value `brk-multihub://` followed by the **domain** that hosts the page, e.g. `brk-multihub://arash-afk.github.io`
  - Domain only: no `https://`, and no path such as `/Microsoft-Outlook-addin` on the end. If you host somewhere else, use that domain (e.g. `brk-multihub://addins.contoso.com`).
- Click **Register**.

### A3. Copy the two IDs
On the app's **Overview** page, copy:
- **Application (client) ID**
- **Directory (tenant) ID**

They're identifiers, not passwords. You'll paste them into `taskpane.html` in part B.

### A4. Add permissions
**API permissions** → **+ Add a permission** → **Microsoft Graph** → **Delegated permissions** → tick:

| Permission | Why |
|---|---|
| `User.Read` (already there) | Sign the lawyer in |
| `Mail.Read` | Read the open email and its attachments, from the lawyer's own mailbox |
| `Sites.ReadWrite.All` | List folders, create folders, upload files and fill in the columns, **only where the lawyer already has access** |

→ **Add permissions**.

"Delegated" means the add-in acts as the signed-in lawyer and is limited to what they can already do. It can't reach any site, folder or mailbox they can't.

### A5. Grant admin consent
Still on **API permissions** → **Grant admin consent for (your organisation)** → **Yes**. All three rows should show a green tick in **Status**. Without this, every lawyer gets *"the add-in hasn't been approved for your organisation yet"*.

### A6. Check Conditional Access (only if your organisation uses it)
If any Conditional Access policy uses the **"Require approved client app"** grant, change it to **"Require app protection policy"**. Microsoft has retired the old grant, and it blocks this kind of add-in sign-in (*"You can't get there from here"*). No client secret or certificate is needed.

---

## Part B — Put the IDs in the add-in and publish (~5 min)

1. Open `taskpane.html`. Near the top of the `<script>` section, paste the two IDs from A3:
   ```js
   const CLIENT_ID = "the Application (client) ID";
   const TENANT_ID = "the Directory (tenant) ID";
   ```
2. Edit the `SITES` list (README, "Configuration reference").
3. Publish **both** of these to your web host (for GitHub Pages: push to the published branch):
   - `taskpane.html`
   - the `lib` folder (it contains `msal-browser-5.25.1.min.js`, Microsoft's sign-in library, and its licence). The page loads it from your own site, not from a third party.

   Wait for it to publish (GitHub Pages: about 1–2 minutes; the **Actions** tab shows it).
4. Deploy `manifest.xml` as described in `README.md`, "Deploy the manifest". Option C needs nothing special in the manifest.

---

## Part C — Test (~15 min)

Use an email with a PDF, a signature logo, and at least one Cc.

1. Open the email → **Save to SharePoint**. The first time, the lawyer may see a short Microsoft sign-in prompt; after that it's silent. **Advanced** shows *"Signed in as …"*.
2. **Step 1** lists only the sites this lawyer can open. Their favourites from before are still there.
3. Pick a site and a folder → **Save**. Expect *"Saved to … with 1 attachment."*
4. In SharePoint: the `.eml` and the PDF are there, **Created by** shows the lawyer, and the Subject / From / To / Cc / InternetMessageId columns are filled in.
5. **Save** again → *"Already filed…"*.
6. As a **second lawyer** (different mailbox): repeat 1–3. Under option B this failed, and now it should work.
7. As a lawyer with **read-only** access to a site: creating a folder or saving shows *"You don't have permission…"*.
8. As a lawyer with **no** access to a site: it isn't in the list. After changing someone's access, **Advanced → Refresh my site access** updates it immediately (otherwise within 12 hours).

---

## Part D — Only if you're moving from option B: switch off its flows

Skip this part on a fresh deployment. If option B was running before, do this **after** part C passes: the old flow URLs are in the old page (and its git history) and keep working until the flows are turned off.

1. <https://make.powerautomate.com> → **My flows**.
2. For each of **Get Folders**, **Create new folder**, **Get email** and **Check site access**: **⋯ → Turn off**.
3. Leave them off for a couple of weeks in case you need to roll back, then delete them.
4. Leave your separate **automatic** email-filing flow alone; this change doesn't touch it.
5. Optional: the flow account no longer needs to be a site owner on every site, so you can reduce it back to what the automatic flow needs.

**To roll back:** turn the flows back on and push the previous (option B) `taskpane.html`.

---

## Good to know

- **Supported Outlook:** Outlook on the web; Outlook for Windows Version 2409 or later (Microsoft 365); Mac 16.89 or later; iOS / Android recent builds. Older Outlook shows *"Please update Outlook"*.
- **Shared mailboxes:** saving from a shared or delegated mailbox isn't supported yet (it would need the extra `Mail.Read.Shared` permission and a small code change). Ask if you need it.
- **Duplicate check:** it only finds earlier copies the lawyer can see. If a copy was filed in a folder they can't access, they can file it again.
- **Large attachments:** files over 4 MB are uploaded in 3.75 MB chunks, so big PDFs work; the status line shows "Saving attachment 2 of 3…".
- **Site list memory:** each computer remembers which sites a lawyer can open for 12 hours (`SITE_ACCESS_CACHE_HOURS`). Folder lists, new folders and saves always go to SharePoint live.

## Troubleshooting

| Message | Cause / fix |
|---|---|
| *Sign-in isn't set up* | `CLIENT_ID` / `TENANT_ID` still say `PASTE-…` (part B1). |
| *…hasn't been approved for your organisation yet* | Admin consent missing (A5). |
| *…sign-in address in the app registration doesn't match* | The SPA redirect URI must be exactly `brk-multihub://<your hosting domain>` (A2). |
| *…your organisation's sign-in policy blocked it* / *You can't get there from here* | Conditional Access (A6). |
| *Please update Outlook* | Outlook is older than the versions above. |
| A site is missing for someone who should see it | They need at least Read on that site's library; then **Refresh my site access**. Also check the `library` name in `SITES` matches the library's URL name. |
| *Couldn't check N site(s)* | Usually a typo in that site's `siteUrl`. |
| *You don't have permission…* | Working as intended: the lawyer has read-only (or no) access there. |
| *…some columns weren't filled in (EmailCc)* | That column is missing in this library (README, SharePoint setup). |
| Blank page / nothing loads | The `lib` folder wasn't pushed (B3). |
