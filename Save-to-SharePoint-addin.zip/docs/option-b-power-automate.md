# Option B — Power Automate version (alternative)

> **Recommended version is option C** (`docs/option-c-graph.md`). Use option B only if you can't register an app in Microsoft Entra, or your users are on Outlook versions older than Windows 2409 / Mac 16.89.

In option B the add-in page (`option-b-power-automate/taskpane.html`) calls **four Power Automate flows** over HTTP. The flows run as one service account (the flow owner) and do all the SharePoint and Outlook work. Before acting, each flow asks SharePoint what the *requesting lawyer* is allowed to do and refuses if they lack access.

| File | What it is |
|---|---|
| `option-b-power-automate/taskpane.html` | The add-in UI for option B. Same look and features as option C; calls the flows instead of Microsoft Graph. |
| `option-b-power-automate/flows/Check site access v3.zip` | Flow: can this user open this site's library? (hides sites they can't) |
| `option-b-power-automate/flows/Get Folders v3.zip` | Flow: lists the library's top-level folders this user can view. |
| `option-b-power-automate/flows/Create new folder v3.zip` | Flow: creates a folder if this user may add items to the library. |
| `option-b-power-automate/flows/Get email v3.zip` | Flow: saves the `.eml` and each attachment if this user may add to the folder, fills in the columns, checks for duplicates. |
| `manifest.xml` (repo root) | Same manifest as option C, with its page address pointed at `option-b-power-automate/taskpane.html` (README, "Deploy the manifest"). |

Order: do the shared **SharePoint setup** in `README.md` first, then parts A4 → B → C → D below. Part F is a manual fallback if a package import fails.

**Licensing:** the HTTP trigger is a standard connector in most tenants, but some tenants block it through DLP policy. Every flow run counts against the flow owner's daily Power Platform request limit.

## How files are named now

Files are prefixed with the email's received date/time (Melbourne/Sydney time), so an email and its attachments sort together and two emails with the same subject never clash:

```
2026-10-29 1405 - RE Settlement offer.eml
2026-10-29 1405 - [1] Deed of Settlement.pdf
2026-10-29 1405 - [2] Schedule A.docx
```

- Characters SharePoint rejects (`" * : < > ? / \ |`) are removed from subjects and attachment names (`RE:` becomes `RE`).
- Subjects are cut to 100 characters.
- Every file (email and attachments) gets the same `InternetMessageId` value, so you can filter the library by it to see an email with all its attachments.
- **Skipped on purpose:** inline images (signature logos, pasted screenshots) and attached Outlook items (an email attached inside an email — that one is still inside the `.eml`). PDFs that Apple Mail marks as "inline" are still saved.

---

## Part A — SharePoint

### A1–A3. Libraries and columns
Follow **"SharePoint setup"** in `README.md` (library URL name, the five columns, the index). It's the same for both options.

### A4. Make the flow account a site owner

The flows run as the account that owns their SharePoint connection (currently `arashvatandoustsakhi@cookiepot.onmicrosoft.com`). From v3 the flows check **other people's** permissions, which SharePoint only allows for site owners (Full Control). So that account must be an **owner of every site** in the list:

- **Modern team site (most sites):** open the site → ⚙️ **Settings** → **Site permissions** → **Add members** → **Add members to group** → add the account → change its role to **Owner**.
- **Communication site / no group:** ⚙️ → **Site permissions** → **Share site only** → add the account → **Full control**.

> If someone gets *"Couldn't check your access to N site(s)"*, this is almost always the cause.

---

## Part B — Import the four flows (~15 min)

Do this once per package in `option-b-power-automate/flows/`.

1. Go to <https://make.powerautomate.com> → check the right **environment** is selected (top right).
2. **My flows** → **Import** → **Import Package (Legacy)** → **Upload** the package → wait for **Package details**.
3. On the flow row, click **Import setup**:
   - **New deployment:** choose **Create as new** (keep the name).
   - **Replacing an existing copy of this flow:** choose **Update** and pick it. Its HTTP URL then stays the same.
4. On each **connection** row (SharePoint; plus Office 365 Outlook for *Get email*) → **Select during import** → pick or create a connection **signed in as the flow account** (the account from A4) → **Save**.
5. **Import**, and wait for the green "successfully imported" message.
6. Repeat for all four packages: *Check site access*, *Get Folders*, *Create new folder*, *Get email*.
7. Open each flow → make sure it's **On** → **Edit**:
   - First step **Allowed_site_prefix** contains `https://cookiepot.sharepoint.com/sites/`. Change it to **your** tenant's address, e.g. `https://contoso.sharepoint.com/sites/` (or `https://contoso.sharepoint.com/` if some sites live under `/teams/`). The flows refuse any site that doesn't start with this.
   - **Save**.
8. In each flow, click the trigger **When a HTTP request is received** and copy its **HTTP URL**. Paste each one into `option-b-power-automate/taskpane.html`:

   | Flow | Constant in the page |
   |---|---|
   | Check site access | `CHECK_SITE_URL` |
   | Get Folders | `LIST_FOLDERS_URL` |
   | Create new folder | `CREATE_FOLDER_URL` |
   | Get email | `SAVE_FLOW_URL` |

   Until all four are filled in, the add-in shows *"The add-in isn't set up…"*.

If an import errors out, use **Part F** to build the changes by hand.

### What each flow expects (for reference)

| Flow | Request body from the add-in | Returns |
|---|---|---|
| Check site access | `{ userEmail, siteUrl, library }` | `{ allowed: true \| false }` |
| Get Folders | `{ userEmail, siteUrl, library }` | `[{ Name, Path }]` — only folders the user can view |
| Create new folder | `{ userEmail, siteUrl, library, folderName }` | `{ Name, Path }`, or `403` if the user can't add to the library |
| Get email | `{ messageId, mailboxAddress, userEmail, siteUrl, library, folderPath }` | `{ result: "saved" \| "duplicate", attachments, warning }`, or `403` |

Each flow also checks the site URL starts with **Allowed_site_prefix** and that the folder is inside the chosen library, and replies `400` otherwise.

## Part C — Add your sites and publish (~5 min)

1. Open `option-b-power-automate/taskpane.html` and find the `SITES` list (near the top of the `<script>`).
2. One line per site. Remove the `//` at the start of a line to turn it on:

   ```js
   const SITES = [
     { name: "Neota",           siteUrl: "https://cookiepot.sharepoint.com/sites/Neota",       library: "Client Correspondence" },
     { name: "Litigation",      siteUrl: "https://cookiepot.sharepoint.com/sites/Litigation",  library: "Client Correspondence" },
     { name: "Property",        siteUrl: "https://cookiepot.sharepoint.com/sites/Property",    library: "Shared Documents" },
     // ...up to 20 (more is fine too)
   ];
   ```

   - `name` — what lawyers see in the dropdown (sorted A–Z automatically).
   - `siteUrl` — no trailing `/`.
   - `library` — the **URL name** from step A1.
   - Keep the comma at the end of each line.
3. Commit and push to `main`. GitHub Pages republishes in 1–2 minutes (repo → **Actions** tab shows when it's done).
4. In Outlook, close and reopen the task pane. If you still see the old version, sign out of Outlook on the web / restart desktop Outlook (Office caches add-in pages).

You do **not** need to re-deploy the manifest for an HTML-only change, but Outlook may keep showing its stored copy for a while (README, "Versioning and caching").

---

## How the permission checks decide

The flows ask SharePoint for the **signed-in lawyer's** effective permissions (including access through SharePoint groups and Microsoft 365 / security groups) and apply these rules:

| What | Shown / allowed when the lawyer has… | Typical permission level |
|---|---|---|
| A site in step 1 | Any access to the site's library (including access to just some folders in it) | Read, Contribute, or "Limited access" |
| A folder in step 2 | Permission to view items in that folder | Read or higher |
| **Create** a folder | Permission to add items to the library | Contribute / Edit or higher |
| **Save** an email | Permission to add items to the chosen folder | Contribute / Edit or higher |

- Folders that **inherit** the library's permissions are checked in one go (fast). Folders with **their own permissions** (e.g. ethical walls) are checked one by one, about half a second each, so a library with 50+ such folders takes noticeably longer to list.
- If a check fails for any reason, the add-in treats it as **no access** (it never shows a folder it couldn't check).
- **Site list memory:** each computer remembers which sites a lawyer can open for **12 hours** (`SITE_ACCESS_CACHE_HOURS` in the page), so the pane opens quickly. Folder lists, new folders and saves are always checked live. After changing someone's site access, they can click **Advanced → Refresh my site access**.
- Setting up permissions in SharePoint: give access at **site level using groups** (one Microsoft 365 or security group per site / practice area). Break inheritance on individual matter folders only for genuine ethical walls.

### Important: what this protects and what it doesn't (option B)

This hides sites and folders from people who shouldn't see them **in the add-in**, and stops normal users creating or saving where they lack access. It is **not** a hard security boundary yet:

- The flows are triggered by URLs that sit in the public `taskpane.html`, and the add-in *tells* the flow who the user is. Someone technical who copies a URL can claim to be another user.
- The site **display names** in the `SITES` list are visible to anyone who opens the page source.

Option C (signing users in with Microsoft 365 and working as them through Microsoft Graph) closes both gaps; plan it as the next step.

**Power Automate usage:** every check is a flow run under the flow owner's account, and each licence has a daily limit on flow actions. Opening the pane for the first time in a day runs one check per site in the list; picking a site runs one folder check. If you roll this out to many lawyers, keep an eye on the flows' **Analytics** page, and consider a Power Automate Premium licence for the flow owner account.

---

## Part D — Test (~10 min)

Use a test email that has **two PDFs** and a signature logo.

1. Open the email → **Save to SharePoint**.
2. **Step 1:** pick a site. The folder box should say "Loading folders…" then "Search folders in …".
3. **Step 2:** click the folder box → existing folders appear. Type a new name → **Create "…" in &lt;site&gt;** → it becomes the selected folder.
4. Click **Save to &lt;site&gt; › &lt;folder&gt;**. Expect: *"Saved to … with 2 attachments."*
5. In SharePoint, open that folder. Expect the `.eml` plus `[1] ….pdf` and `[2] ….pdf`, and **no** logo image. Add the `InternetMessageId` column to the view and check all three files have the same value.
6. Click **Save** again on the same email. Expect: *"Already filed…"* and no new files.
7. Switch to a second site and repeat steps 2–4.
8. Search: in the site's search box, search for a phrase that appears **inside** one of the PDFs. New files can take from a few minutes up to a few hours to appear in search results.

## Part D2 — Test permissions and favourites (~15 min)

You need two test accounts: **A** with Contribute (Edit) access to a site, and **B** with no access to that site.

**Permissions**

1. As **A**: open the pane → the site appears in step 1 (the first open of the day shows *"Checking your access…"* for a few seconds).
2. As **B**: the site is **not** in the list.
3. In that site's library, give one matter folder its own permissions (folder → **Manage access** → **Advanced settings** → **Stop inheriting permissions**) and remove **A**. As **A**, click **Advanced → Refresh my site access**, pick the site: that folder is gone; the others are there.
4. Give **B** **Read** on the library. As **B**, refresh, pick the site, try to create a folder → *"You don't have permission to create folders…"*. Pick a folder and Save → *"You don't have permission to save into this folder…"*.

**Favourites**

5. Pick a site → click ☆ next to the site box → it appears under **Favourites** as *(whole site)*, and the star turns gold ★.
6. Pick a folder → click ☆ next to the folder name → it appears under Favourites.
7. Add favourites until you have 5 → a 6th is refused with a message.
8. Remove one with **×** → it disappears. Clicking a gold ★ also removes that site/folder from favourites.
9. Switch to another site, then click a folder favourite → site and folder are filled in, ready to save.
10. Open Outlook on the web as the same user → the same favourites are there.
11. Remove the user's access to a favourited site → after **Refresh my site access**, that favourite shows *no access* (greyed) but can still be removed with **×**.

---

## Part E — Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| Folder box says "Couldn't load folders" | Wrong `siteUrl` or `library` in `SITES`, or the flow account has no access to that site (A4). Check the **Get Folders** run history. |
| *"This request isn't allowed…"* | The site URL doesn't start with **Allowed_site_prefix** in the flow (B7). |
| "Saving didn't finish…" | Open **Get email** run history. Most common: `InternetMessageId` column missing in that library (README, SharePoint setup), or no edit permission (A4). |
| "Saved …, but: Some columns weren't filled in: EmailCc (…)" | That column doesn't exist in this library, or was created with a different name. Create it exactly as in README, SharePoint setup. |
| Subject/From/To/Cc empty on files saved earlier | Expected: only saves after the columns were added are filled in. |
| "Still saving in the background" | Large attachments took over ~2 minutes; the flow keeps running. Check the folder shortly. |
| Duplicate check stops working on a big library | Column not indexed (README, SharePoint setup). |
| A scanned PDF isn't found by search | It has no text layer. SharePoint only searches text that's in the PDF; scanned images need OCR first (ask your M365 admin about SharePoint's OCR feature, or OCR before sending). |
| Colleague gets an error on every save | See "Known limitation" below. |
| *"The add-in isn't set up…"* and no sites | One of the four flow URLs in `option-b-power-automate/taskpane.html` is still a `PASTE-…` placeholder (B8). |
| *"Couldn't check your access to N site(s)"* | The flow account isn't an owner of that site (A4), or that site's `siteUrl` / `library` in `SITES` is wrong. Check **Check site access** run history. |
| A lawyer doesn't see a site they should | They need at least Read on the site's library. After granting it: **Advanced → Refresh my site access**. |
| A folder they should see is missing | That folder has its own permissions and they're not included. Check the folder's **Manage access**. |
| *"You don't have permission to…"* | Working as intended: they have read-only (or no) access there. Give them Contribute/Edit if they should file there. |
| Favourites row shows *no access* | They lost access to that site, or it was removed from `SITES`. Remove it with **×**. |
| Favourites don't save | Rare Outlook sync issue; try again. Favourites live in the user's mailbox, so they need to be online. |

### Known limitation (unchanged from v1)

**Get email (V2)** and **Export email (V2)** run as the flow owner's Outlook connection, so they can only read messages in mailboxes that account can open. If other lawyers will use the add-in on their own mailboxes, the flow account needs access to those mailboxes (e.g. a shared mailbox setup), and the flow should pass the add-in's `mailboxAddress` into the **Original Mailbox Address** field of both actions. Test with a second user before rollout.

### Why the flows use "Send an HTTP request to SharePoint"

The standard SharePoint actions (Create new folder, Get items, Update file properties) need the library picked from a dropdown at design time, so they can't switch between 20 sites at run time. The REST calls take the site and library from the request instead. **Create file** still uses the normal action because it accepts a site address and folder path as text and handles large files.

---

## Part F — Manual fallback: make the changes in the flow designer

Only needed if a package import (Part B) fails. In the designer, paste each expression into the **Expression** tab (the `fx` box), without a leading `@`.

Common to all three flows — add these at the very top, right after the trigger:

1. **Trigger → Request Body JSON Schema**: add the new properties (see table in Part B), e.g. for Get Folders:
   ```json
   { "type": "object", "properties": { "siteUrl": { "type": "string" }, "library": { "type": "string" } } }
   ```
2. **Compose** renamed `Allowed_site_prefix` — Inputs (plain text): `https://cookiepot.sharepoint.com/sites/`
3. **Compose** renamed `Site_path` — Inputs (expression):
   ```
   if(endsWith(uriPath(triggerBody()?['siteUrl']),'/'),take(uriPath(triggerBody()?['siteUrl']),sub(length(uriPath(triggerBody()?['siteUrl'])),1)),uriPath(triggerBody()?['siteUrl']))
   ```
4. **Compose** renamed `Library_path` — Inputs (expression):
   ```
   concat(outputs('Site_path'),'/',trim(coalesce(triggerBody()?['library'],'')))
   ```
5. Every SharePoint action: **Site Address → Enter custom value →** expression `triggerBody()?['siteUrl']`.

### F1. Get Folders

- **Send an HTTP request to SharePoint** → Uri:
  ```
  _api/web/GetFolderByServerRelativeUrl('@{replace(outputs('Library_path'),'''','''''')}')/Folders?$select=Name,ServerRelativeUrl
  ```
  (Type the text, and insert the part inside `@{ }` as an expression.)
- Everything after it (Parse JSON → Filter array → Select → Response) stays as it was.

### F2. Create new folder

- **Delete** the old *Create new folder* action.
- Add **Send an HTTP request to SharePoint**, rename it `Create_new_folder`:
  - Method: `POST`
  - Uri: `_api/web/folders/add('` + expression `replace(concat(outputs('Library_path'),'/',trim(triggerBody()?['folderName'])),'''','''''')` + `')`
  - Headers: `Accept` = `application/json;odata=nometadata`
- **Response** → Body:
  ```json
  { "Name": "@{body('Create_new_folder')?['Name']}", "Path": "@{body('Create_new_folder')?['ServerRelativeUrl']}" }
  ```

### F3. Get email — folder, file names and duplicate check

After the common steps, add:

1. **Compose** `Target_folder`:
   ```
   if(empty(trim(coalesce(triggerBody()?['folderPath'],''))),outputs('Library_path'),triggerBody()?['folderPath'])
   ```
2. **Compose** `Folder_in_site`: `substring(outputs('Target_folder'),length(outputs('Site_path')))`
3. Keep **Get email (V2)** (Include Attachments = Yes) and **Export email (V2)**.
4. **Compose** `File_name_prefix`:
   ```
   convertFromUtc(formatDateTime(coalesce(outputs('Get_email_(V2)')?['body/receivedDateTime'],utcNow()),'yyyy-MM-ddTHH:mm:ssZ'),'AUS Eastern Standard Time','yyyy-MM-dd HHmm')
   ```
5. **Compose** `Email_file_name`:
   ```
   concat(outputs('File_name_prefix'),' - ',trim(take(trim(replace(replace(replace(replace(replace(replace(replace(replace(replace(if(empty(outputs('Get_email_(V2)')?['body/subject']),'(no subject)',outputs('Get_email_(V2)')?['body/subject']),'"',''),'*',''),':',''),'<',''),'>',''),'?',''),'/','-'),'\','-'),'|','')),100)),'.eml')
   ```
6. **Replace** the old *Get items* with **Send an HTTP request to SharePoint**, renamed `Check_duplicate`:
   - Method `POST`, Uri `_api/web/GetList('@{replace(outputs('Library_path'),'''','''''')}')/GetItems`
   - Headers: `Accept` and `Content-Type` = `application/json;odata=nometadata`
   - Body:
     ```
     {"query":{"ViewXml":"<View Scope='RecursiveAll'><Query><Where><Eq><FieldRef Name='InternetMessageId'/><Value Type='Text'>@{replace(replace(replace(outputs('Get_email_(V2)')?['body/internetMessageId'],'&','&amp;'),'<','&lt;'),'>','&gt;')}</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"}}
     ```
7. **Condition**: expression `empty(body('Check_duplicate')?['value'])` **is equal to** `true`.

### F4. Get email — the attachment loop (this is requirement 2)

Before the Condition (so the Response can count them):

1. **Filter array** renamed `Filter_attachments`
   - From: `coalesce(outputs('Get_email_(V2)')?['body/attachments'],json('[]'))`
   - Edit in advanced mode:
     ```
     @and(not(empty(item()?['contentBytes'])),or(not(equals(item()?['isInline'],true)),not(startsWith(toLower(coalesce(item()?['contentType'],'')),'image/'))))
     ```
2. **Select** renamed `Number_attachments`
   - From: `take(range(0,add(length(body('Filter_attachments')),1)),length(body('Filter_attachments')))`
   - Map (switch to text mode and paste):
     ```
     {
       "n": "@add(item(),1)",
       "name": "@{body('Filter_attachments')[item()]?['name']}",
       "contentBytes": "@body('Filter_attachments')[item()]?['contentBytes']"
     }
     ```

Inside the Condition's **True** branch:

3. **Create file** (email): Site Address = `triggerBody()?['siteUrl']`, Folder Path = `outputs('Folder_in_site')`, File Name = `outputs('Email_file_name')`, File Content = Export email body. Keep chunking on.
4. Replace *Update file properties* with **Compose** `Tag_email_body`:
   ```json
   {"formValues":[
     {"FieldName":"InternetMessageId","FieldValue":"@{outputs('Get_email_(V2)')?['body/internetMessageId']}"},
     {"FieldName":"EmailSubject","FieldValue":"@{take(coalesce(outputs('Get_email_(V2)')?['body/subject'],''),255)}"},
     {"FieldName":"EmailFrom","FieldValue":"@{take(coalesce(outputs('Get_email_(V2)')?['body/from'],''),255)}"},
     {"FieldName":"EmailTo","FieldValue":"@{coalesce(outputs('Get_email_(V2)')?['body/toRecipients'],'')}"},
     {"FieldName":"EmailCc","FieldValue":"@{coalesce(outputs('Get_email_(V2)')?['body/ccRecipients'],'')}"}
   ],"bNewDocumentUpdate":true}
   ```
   then **Send an HTTP request to SharePoint** `Tag_email`: Method `POST`, Uri
   `_api/web/GetList('@{replace(outputs('Library_path'),'''','''''')}')/items(@{outputs('Create_file')?['body/ItemId']})/ValidateUpdateListItem`, same two headers, Body `@{outputs('Tag_email_body')}`.
5. **Apply to each** renamed `For_each_attachment`, over `body('Number_attachments')`. Inside it:
   - **Create file** `Create_attachment_file`: same Site Address and Folder Path;
     File Name: `concat(outputs('File_name_prefix'),' - [',items('For_each_attachment')?['n'],'] ',items('For_each_attachment')?['name'])`;
     File Content: `base64ToBinary(items('For_each_attachment')?['contentBytes'])`
   - **Compose** `Tag_attachment_body` — same as step 4.
   - **Send an HTTP request to SharePoint** `Tag_attachment` — same as `Tag_email` but with `outputs('Create_attachment_file')?['body/ItemId']`.

After the Condition:

6. **Response** (run after Condition *is successful*), Body:
   ```json
   {"result":"@{if(empty(body('Check_duplicate')?['value']),'saved','duplicate')}","attachments":@{if(empty(body('Check_duplicate')?['value']),length(body('Filter_attachments')),0)}}
   ```
7. A second **Response** with status `500`, body `{"message":"Saving didn't finish."}`, set to run after Condition *has failed / is skipped / has timed out* (⋯ → **Configure run after**). This stops the add-in waiting forever when something breaks.

### F5. Permission checks (v3)

Add these to each flow, **right after** the `Check_request` condition. Every flow also needs `userEmail` added to its trigger schema: `"userEmail": { "type": "string" }`.

1. **Send an HTTP request to SharePoint**, renamed `Ensure_user`: Method `POST`, Uri `_api/web/ensureuser`, headers as in F3, Body (expression):
   ```
   setProperty(json('{}'),'logonName',trim(triggerBody()?['userEmail']))
   ```
2. **Send an HTTP request to SharePoint**, renamed `Library_perms` (in Get email call it `Target_perms` and use the folder instead of the list): Method `GET`, Uri:
   ```
   _api/web/GetList('@{outputs('Library_path')}')/getusereffectivepermissions(@u)?@u='@{encodeUriComponent(body('Ensure_user')?['LoginName'])}'
   ```
   For Get email (folder): `_api/web/GetFolderByServerRelativeUrl('@{outputs('Target_folder')}')/ListItemAllFields/getusereffectivepermissions(@u)?@u='@{encodeUriComponent(body('Ensure_user')?['LoginName'])}'`
3. Test a permission bit with a **Condition**, expression `... is equal to 1`:
   - can **view** items: `mod(int(string(body('Library_perms')?['Low'])),2)`
   - can **add** items: `mod(div(int(string(body('Library_perms')?['Low'])),2),2)`
   - can **open** the library at all (Check site access): `mod(div(int(string(body('Library_perms')?['Low'])),65536),2)`
4. In the **No** branch: a **Response** with status `403` and `{"message":"You don't have permission…"}`, then **Terminate** (Cancelled).

**Get Folders** additionally: change the folder Uri to
`_api/web/GetFolderByServerRelativeUrl('@{outputs('Library_path')}')/Folders?$select=Name,ServerRelativeUrl,ListItemAllFields/Id,ListItemAllFields/HasUniqueRoleAssignments&$expand=ListItemAllFields`,
return folders that inherit permissions only if the user can view the library, and check folders where `ListItemAllFields/HasUniqueRoleAssignments` is true one by one (**Apply to each** with concurrency off, calling `.../items(<Id>)/getusereffectivepermissions(...)` and **Append to array variable** when the view bit is 1). Importing the package is much easier than building this by hand.

